// Replace this with your contract address
export const myEditionDropContractAddress: string = "0xDC8017E1E20BFF80a49B0B92F719f00170013B4F";

// Replace this with your token id
export const tokenId: string = "0";